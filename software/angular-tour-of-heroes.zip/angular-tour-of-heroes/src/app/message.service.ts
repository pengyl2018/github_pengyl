import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class MessageService {
  messages: string[] = [];

  public addMessage(message: string){
    this.messages.push(message);
  }

  public showMessageList(){
    return this.messages;
  }

  public clear(){
    this.messages = [];
    return this.messages;
  }

  constructor() { }
}
