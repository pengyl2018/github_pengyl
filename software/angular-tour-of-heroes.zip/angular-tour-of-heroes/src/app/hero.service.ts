import { Injectable } from '@angular/core';
import {Hero} from './hero';
import { Heroes} from './hero-list';
import { Observable, of } from 'rxjs';  //使用 RxJS 的 of() 函数来模拟从服务器返回数据
import { MessageService } from './message.service';
import { HttpClient, HttpHeaders} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class HeroService {

  private headers: HttpHeaders;

  constructor(
    private http: HttpClient,
    //添加一个私有的 messageService 属性参数, 创建 HeroService 时把 MessageService 的单例注入到这个属性中
    private messageService: MessageService
  ) {
    this.headers = new HttpHeaders();
    this.headers.set('Content-Type', 'application/json');
  }

  public getHeroes(): Observable<Hero[]>{
    //当遍历英雄组合时
    this.messageService.addMessage("Invoking HeroService and show hero list");
    return of(Heroes);
  }

  public getHero(id: number): Observable<Hero> {
    // TODO: send the message _after_ fetching the hero
    this.messageService.addMessage("HeroService: fetched hero id=" + id);
    return of(Heroes.find(hero => hero.id === id));
  }

}
