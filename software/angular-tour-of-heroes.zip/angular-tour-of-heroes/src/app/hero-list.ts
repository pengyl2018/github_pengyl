import {Hero} from './hero';

export const Heroes: Hero[] = [
  {id: 2, name: 'Bloodmage', type: 'HUM'},
  {id: 4, name: 'Death Knight', type: 'Undying'},
  {id: 5, name: 'KOTH', type: 'HUM'},
  {id: 7, name: 'Forest Defense', type: 'Night Elves'},
  {id: 10, name: 'Crypy Lord', type: 'Undying'},
  {id: 12, name: 'Prophet', type: 'Beast'},
  {id: 13, name: 'DarkRanger', type: 'Neutral'},
  {id: 14, name: 'Holy Knight', type: 'HUM'},
  {id: 15, name: 'Fire Lord', type: 'Neutral'}
]
