import { Component, OnInit } from '@angular/core';
import {Hero} from '../hero';
import { HeroService} from '../hero.service';

@Component({
  selector: 'app-heroes',
  templateUrl: './heroes.component.html',
  styleUrls: ['./heroes.component.scss']
})
export class HeroesComponent implements OnInit {

  //把 heroes 属性的定义改为一句简单的声明,因为Hero[]数组接口已经在hero.ts中被定义。
  heroes: Hero[];

  constructor(
    private heroService: HeroService
  ) { }

  ngOnInit() {
    this.getHeroList();
  }

  public getHeroList(){
    return this.heroService.getHeroes().subscribe(heroes => this.heroes = heroes);
  }

}
