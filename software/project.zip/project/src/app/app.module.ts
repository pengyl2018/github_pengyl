import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ProductListComponent } from './product-list/product-list.component';
import {RouterModule} from "@angular/router";
import { ProductAlertComponent } from './product-alert/product-alert.component';
import { ProductDetailComponent } from './product-detail/product-detail.component';
import { ShoppingCartComponent } from './shopping-cart/shopping-cart.component';
import { HttpClientModule} from "@angular/common/http";
import {ReactiveFormsModule} from "@angular/forms";
import { ShippingComponent } from './shipping/shipping.component';
import { BootstrapComponent } from './bootstrap/bootstrap.component';
import { BootstrapFormComponent } from './bootstrap-form/bootstrap-form.component';
import { BootstrapTabComponent } from './bootstrap-tab/bootstrap-tab.component';
import { BootstrapPluginComponent } from './bootstrap-plugin/bootstrap-plugin.component';

@NgModule({
  declarations: [
    AppComponent,
    ProductListComponent,
    ProductAlertComponent,
    ProductDetailComponent,
    ShoppingCartComponent,
    ShippingComponent,
    BootstrapComponent,
    BootstrapFormComponent,
    BootstrapTabComponent,
    BootstrapPluginComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    ReactiveFormsModule,   //表单路由器
    AppRoutingModule,
    FormsModule,
    RouterModule.forRoot([
      { path: '', component: ProductListComponent },
      { path: 'products/:productId', component: ProductDetailComponent},
      { path: 'shoppingcart', component: ShoppingCartComponent},
      { path: 'shipping', component: ShippingComponent},
      { path: 'bootstrap', component: BootstrapComponent},
      { path: 'bootstrap-form', component: BootstrapFormComponent},
      { path: 'bootstrap-tab', component: BootstrapTabComponent},
      { path: 'bootstrap-plugin', component: BootstrapPluginComponent}
      ]
    )
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
