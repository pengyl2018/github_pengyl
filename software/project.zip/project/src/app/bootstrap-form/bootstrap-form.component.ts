import { Component, OnInit } from '@angular/core';
import {Location} from '@angular/common';

@Component({
  selector: 'app-bootstrap-form',
  templateUrl: './bootstrap-form.component.html',
  styleUrls: ['./bootstrap-form.component.scss']
})
export class BootstrapFormComponent implements OnInit {

  constructor(
    private location: Location
  ) { }

  ngOnInit() {
  }

  public showHieight(){
    alert("height==="+ window.screen.availHeight + "px");
  }

  public showWidth(){
    alert("width==="+ window.screen.availWidth + "px");
  }

  public goAhead(){
    this.location.forward();
  }

  public goBack(){
    this.location.back();
  }

  public refresh(){
    window.location.reload();
  }
}
