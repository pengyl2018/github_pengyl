import { Component, OnInit } from '@angular/core';
import { ShoppingcartService } from '../shoppingcart.service';

@Component({
  selector: 'app-shipping',
  templateUrl: './shipping.component.html',
  styleUrls: ['./shipping.component.scss']
})
export class ShippingComponent implements OnInit {
  shippingCosts;

  constructor(
    private shoppingcartService: ShoppingcartService
  ) { }

  ngOnInit() {
    this.shippingCosts = this.shoppingcartService.getShippingPrices();
  }

  goBack(){
    history.go(-1);
  }

}
