import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bootstrap-tab',
  templateUrl: './bootstrap-tab.component.html',
  styleUrls: ['./bootstrap-tab.component.scss']
})
export class BootstrapTabComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
