import { Component, OnInit } from '@angular/core';
import * as $ from 'jquery';

@Component({
  selector: 'app-bootstrap-plugin',
  templateUrl: './bootstrap-plugin.component.html',
  styleUrls: ['./bootstrap-plugin.component.scss']
})
export class BootstrapPluginComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    this.load();
  }

  load() {

    // @ts-ignore
    $('#myTab li:eq(1) a').tab('show');
    // @ts-ignore
    $('[data-toggle=\'tooltip\']').tooltip();
    // @ts-ignore
    $('[data-toggle=\'popover\']').popover();
  }
}
