import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BootstrapPluginComponent } from './bootstrap-plugin.component';

describe('BootstrapPluginComponent', () => {
  let component: BootstrapPluginComponent;
  let fixture: ComponentFixture<BootstrapPluginComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BootstrapPluginComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BootstrapPluginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
