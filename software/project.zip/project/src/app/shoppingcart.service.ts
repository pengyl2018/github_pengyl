import { Injectable } from '@angular/core';
import { HttpClient} from "@angular/common/http";

@Injectable({
  providedIn: 'root'
})
export class ShoppingcartService {

  //定义购物车服务的初始化数组对象
  items = [];

  //定义购物车服务商品新增删除查询列表的方法

  public addToShoppingCart(product){
    this.items.push(product);
  }

  public getShoppingCartItems(){
    return this.items;
  }

  public clearShoppingCart(){
    this.items = [];
  }

  public getShippingPrices(){
    return this.http.get('../../assets/shipping.json');
  }

  constructor(
    private http: HttpClient
  ) { }
}
