export const products = [
  {
    name: 'Apple',
    price: 26.70
  },
  {
    name: 'Pears',
    price: 32.45,
    description: '梨子'
  },
  {
    name: 'Orange',
    price: 46.70
  },
  {
    name: 'Cherries',
    price: 104.51,
    description: '车厘子'
  },
  {
    name: 'Banana',
    price: 30.14,
    description: '香蕉'
  }
]
